"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_users_users_module_ts"],{

/***/ 7425:
/*!***********************************************!*\
  !*** ./src/app/users/users-routing.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UsersPageRoutingModule": () => (/* binding */ UsersPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _users_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./users.page */ 8484);




const routes = [
    {
        path: '',
        component: _users_page__WEBPACK_IMPORTED_MODULE_0__.UsersPage
    }
];
let UsersPageRoutingModule = class UsersPageRoutingModule {
};
UsersPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], UsersPageRoutingModule);



/***/ }),

/***/ 1951:
/*!***************************************!*\
  !*** ./src/app/users/users.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UsersPageModule": () => (/* binding */ UsersPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _users_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./users-routing.module */ 7425);
/* harmony import */ var _users_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./users.page */ 8484);
/* harmony import */ var ng2_search_filter__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ng2-search-filter */ 9991);








let UsersPageModule = class UsersPageModule {
};
UsersPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _users_routing_module__WEBPACK_IMPORTED_MODULE_0__.UsersPageRoutingModule,
            ng2_search_filter__WEBPACK_IMPORTED_MODULE_2__.Ng2SearchPipeModule
        ],
        declarations: [_users_page__WEBPACK_IMPORTED_MODULE_1__.UsersPage]
    })
], UsersPageModule);



/***/ }),

/***/ 8484:
/*!*************************************!*\
  !*** ./src/app/users/users.page.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UsersPage": () => (/* binding */ UsersPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _users_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./users.page.html?ngResource */ 5466);
/* harmony import */ var _users_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./users.page.scss?ngResource */ 5890);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _service_user_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../service/user.service */ 4981);
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! xlsx */ 4126);








let UsersPage = class UsersPage {
    constructor(API, alertController, route) {
        this.API = API;
        this.alertController = alertController;
        this.route = route;
        this.user = [];
        this.Filter = "";
    }
    ngOnInit() {
        this.API.getAllUser().subscribe(res => {
            console.log(res);
            this.user = res;
        });
    }
    viewProfile(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.route.navigateByUrl("/user-profile/" + id);
        });
    }
    exportexcel() {
        /* pass here the table id */
        const workBook = xlsx__WEBPACK_IMPORTED_MODULE_4__.utils.book_new(); // create a new blank book
        const workSheet = xlsx__WEBPACK_IMPORTED_MODULE_4__.utils.json_to_sheet(this.user);
        xlsx__WEBPACK_IMPORTED_MODULE_4__.utils.book_append_sheet(workBook, workSheet, 'Users List'); // add the worksheet to the book
        xlsx__WEBPACK_IMPORTED_MODULE_4__.writeFile(workBook, 'All Users List - ' + new Date + '.xlsx');
    }
};
UsersPage.ctorParameters = () => [
    { type: _service_user_service__WEBPACK_IMPORTED_MODULE_2__.UserService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.AlertController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router }
];
UsersPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-users',
        template: _users_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_users_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], UsersPage);



/***/ }),

/***/ 5890:
/*!**************************************************!*\
  !*** ./src/app/users/users.page.scss?ngResource ***!
  \**************************************************/
/***/ ((module) => {

module.exports = "ion-card {\n  --background: yellow;\n}\nion-card p {\n  font-weight: 300;\n}\nion-card ion-card-subtitle {\n  font-size: large;\n  font-weight: bold;\n  color: black;\n  padding-bottom: 2px;\n}\nion-card .date {\n  font-weight: bold;\n  color: black;\n}\nion-card .icon {\n  font-size: 25px;\n  color: black;\n  padding-left: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZXJzLnBhZ2Uuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFwuLlxcSW9uaWMlMjBQcm9qZWN0XFxoa2drZnVuZHNcXHNyY1xcYXBwXFx1c2Vyc1xcdXNlcnMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksb0JBQUE7QUNDSjtBRENJO0VBQ0MsZ0JBQUE7QUNDTDtBRENJO0VBQ0ksZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtBQ0NSO0FEQ0k7RUFDSSxpQkFBQTtFQUNBLFlBQUE7QUNDUjtBRENJO0VBQ0ksZUFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQ0NSIiwiZmlsZSI6InVzZXJzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jYXJke1xyXG4gICAgLS1iYWNrZ3JvdW5kIDogeWVsbG93O1xyXG4gIFxyXG4gICAgcHtcclxuICAgICBmb250LXdlaWdodDogMzAwO1xyXG4gICAgfVxyXG4gICAgaW9uLWNhcmQtc3VidGl0bGV7XHJcbiAgICAgICAgZm9udC1zaXplOiBsYXJnZTtcclxuICAgICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgICAgICBjb2xvcjogYmxhY2s7XHJcbiAgICAgICAgcGFkZGluZy1ib3R0b206IDJweDtcclxuICAgIH1cclxuICAgIC5kYXRle1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgICAgIGNvbG9yOiBibGFjaztcclxuICAgIH1cclxuICAgIC5pY29ue1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMjVweDtcclxuICAgICAgICBjb2xvcjogYmxhY2s7XHJcbiAgICAgICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xyXG4gICAgfVxyXG4gIH0iLCJpb24tY2FyZCB7XG4gIC0tYmFja2dyb3VuZDogeWVsbG93O1xufVxuaW9uLWNhcmQgcCB7XG4gIGZvbnQtd2VpZ2h0OiAzMDA7XG59XG5pb24tY2FyZCBpb24tY2FyZC1zdWJ0aXRsZSB7XG4gIGZvbnQtc2l6ZTogbGFyZ2U7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBjb2xvcjogYmxhY2s7XG4gIHBhZGRpbmctYm90dG9tOiAycHg7XG59XG5pb24tY2FyZCAuZGF0ZSB7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBjb2xvcjogYmxhY2s7XG59XG5pb24tY2FyZCAuaWNvbiB7XG4gIGZvbnQtc2l6ZTogMjVweDtcbiAgY29sb3I6IGJsYWNrO1xuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG59Il19 */";

/***/ }),

/***/ 5466:
/*!**************************************************!*\
  !*** ./src/app/users/users.page.html?ngResource ***!
  \**************************************************/
/***/ ((module) => {

module.exports = "<ion-toolbar color=\"primary\">\n  <ion-buttons slot=\"start\">\n   <ion-menu-button *ngIf=\"!back\" style=\"color: black;\"></ion-menu-button>\n   <ion-title style=\"color: black;\"> HKGK Funds </ion-title>\n   <ion-back-button *ngIf=\"back\" defaultHref=\"/home\"></ion-back-button>\n  </ion-buttons>\n  <ion-buttons slot=\"end\">\n    <ion-button fill=\"clear\" (click)=\"exportexcel()\" > <i class=\"fa-solid fa-file-export\" style=\"font-size: large; color: black;\"></i> </ion-button>\n    <ion-button fill=\"clear\" (click)=\"ngOnInit()\" > \n      <i class=\"fas fa-sync-alt\" style=\"font-size: large; color: black;\"   aria-hidden=\"true\"></i>\n     </ion-button>\n   </ion-buttons>\n</ion-toolbar>\n<ion-content [fullscreen]=\"true\">\n  <ion-searchbar style=\"color: black;\" color=\"primary\" [(ngModel)]=\"Filter\"></ion-searchbar>\n  <ion-card *ngFor=\"let item of user | filter:Filter\" (click)=\"viewProfile(item.autoNumber)\" class=\"ion-margin\">\n    <ion-card-header>     \n      <ion-card-subtitle>\n        {{item.autoNumber}}\n      </ion-card-subtitle>\n      <ion-item>\n        <ion-col size=\"8\"><ion-label>{{item.userName}} </ion-label></ion-col>\n        <ion-col size=\"4\"><ion-label>₹{{ item.userBalanceAmount}}</ion-label></ion-col>       \n      </ion-item>\n    </ion-card-header>\n    <ion-card-content>\n      <ion-label class=\"date\">Accepted ₹{{item.userAcceptedAmount}} <ion-icon class=\"icon\" name=\"arrow-redo-outline\"></ion-icon></ion-label>\n    </ion-card-content>\n  </ion-card>\n</ion-content>\n ";

/***/ })

}]);
//# sourceMappingURL=src_app_users_users_module_ts.js.map