"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_user-transaction_user-transaction_module_ts"],{

/***/ 4331:
/*!*********************************************************************!*\
  !*** ./src/app/user-transaction/user-transaction-routing.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserTransactionPageRoutingModule": () => (/* binding */ UserTransactionPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _user_transaction_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./user-transaction.page */ 676);




const routes = [
    {
        path: ':id',
        component: _user_transaction_page__WEBPACK_IMPORTED_MODULE_0__.UserTransactionPage
    }
];
let UserTransactionPageRoutingModule = class UserTransactionPageRoutingModule {
};
UserTransactionPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], UserTransactionPageRoutingModule);



/***/ }),

/***/ 7606:
/*!*************************************************************!*\
  !*** ./src/app/user-transaction/user-transaction.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserTransactionPageModule": () => (/* binding */ UserTransactionPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _user_transaction_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./user-transaction-routing.module */ 4331);
/* harmony import */ var _user_transaction_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./user-transaction.page */ 676);
/* harmony import */ var ng2_search_filter__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ng2-search-filter */ 9991);








let UserTransactionPageModule = class UserTransactionPageModule {
};
UserTransactionPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _user_transaction_routing_module__WEBPACK_IMPORTED_MODULE_0__.UserTransactionPageRoutingModule,
            ng2_search_filter__WEBPACK_IMPORTED_MODULE_2__.Ng2SearchPipeModule
        ],
        declarations: [_user_transaction_page__WEBPACK_IMPORTED_MODULE_1__.UserTransactionPage]
    })
], UserTransactionPageModule);



/***/ }),

/***/ 676:
/*!***********************************************************!*\
  !*** ./src/app/user-transaction/user-transaction.page.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserTransactionPage": () => (/* binding */ UserTransactionPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _user_transaction_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./user-transaction.page.html?ngResource */ 3919);
/* harmony import */ var _user_transaction_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./user-transaction.page.scss?ngResource */ 8220);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _class_transaction__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../class/transaction */ 8407);
/* harmony import */ var _service_transaction_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../service/transaction.service */ 1263);








let UserTransactionPage = class UserTransactionPage {
    constructor(route, API, arouter, router, alertCtrl) {
        this.route = route;
        this.API = API;
        this.arouter = arouter;
        this.router = router;
        this.alertCtrl = alertCtrl;
        this.Filter = "";
        this.User = new _class_transaction__WEBPACK_IMPORTED_MODULE_2__.Transaction();
        this.active = true;
        this.nonactive = false;
    }
    ngOnInit() {
        this.id = this.arouter.snapshot.paramMap.get("id");
        console.log(this.id);
        this.API.getSingleUser(this.id).subscribe(res => {
            console.log(res);
            this.User = res;
        });
    }
    activecolor() {
        // debugger
        this.route.navigateByUrl("/user-profile/" + this.User.autoNumber);
    }
    deleteUser(id) {
        this.API.deleteSingleUser(this.id).subscribe(res => {
            console.log(res);
            this.showAlert(res);
            this.router.navigateByUrl("/viewalltransaction");
        });
    }
    showAlert(res) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                header: 'Alert',
                subHeader: 'Delete',
                message: res + ' ' + this.User.userName,
                buttons: ['OK']
            });
            yield alert.present();
            const result = yield alert.onDidDismiss();
            console.log(result);
        });
    }
};
UserTransactionPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router },
    { type: _service_transaction_service__WEBPACK_IMPORTED_MODULE_3__.TransactionService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController }
];
UserTransactionPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-user-transaction',
        template: _user_transaction_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_user_transaction_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], UserTransactionPage);



/***/ }),

/***/ 9991:
/*!**************************************************************************!*\
  !*** ./node_modules/ng2-search-filter/__ivy_ngcc__/ng2-search-filter.js ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ng2SearchPipeModule": () => (/* binding */ Ng2SearchPipeModule),
/* harmony export */   "Ng2SearchPipe": () => (/* binding */ Ng2SearchPipe)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 3184);



class Ng2SearchPipe {
    /**
     * @param {?} items object from array
     * @param {?} term term's search
     * @return {?}
     */
    transform(items, term) {
        if (!term || !items)
            return items;
        return Ng2SearchPipe.filter(items, term);
    }
    /**
     *
     * @param {?} items List of items to filter
     * @param {?} term  a string term to compare with every property of the list
     *
     * @return {?}
     */
    static filter(items, term) {
        const /** @type {?} */ toCompare = term.toLowerCase();
        /**
         * @param {?} item
         * @param {?} term
         * @return {?}
         */
        function checkInside(item, term) {
            for (let /** @type {?} */ property in item) {
                if (item[property] === null || item[property] == undefined) {
                    continue;
                }
                if (typeof item[property] === 'object') {
                    if (checkInside(item[property], term)) {
                        return true;
                    }
                }
                if (item[property].toString().toLowerCase().includes(toCompare)) {
                    return true;
                }
            }
            return false;
        }
        return items.filter(function (item) {
            return checkInside(item, term);
        });
    }
}
Ng2SearchPipe.ɵfac = function Ng2SearchPipe_Factory(t) { return new (t || Ng2SearchPipe)(); };
Ng2SearchPipe.ɵpipe = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefinePipe"]({ name: "filter", type: Ng2SearchPipe, pure: false });
Ng2SearchPipe.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: Ng2SearchPipe, factory: Ng2SearchPipe.ɵfac });
/**
 * @nocollapse
 */
Ng2SearchPipe.ctorParameters = () => [];
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](Ng2SearchPipe, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Pipe,
        args: [{
                name: 'filter',
                pure: false
            }]
    }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Injectable
    }], null, null); })();

class Ng2SearchPipeModule {
}
Ng2SearchPipeModule.ɵfac = function Ng2SearchPipeModule_Factory(t) { return new (t || Ng2SearchPipeModule)(); };
Ng2SearchPipeModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({ type: Ng2SearchPipeModule });
Ng2SearchPipeModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({});
/**
 * @nocollapse
 */
Ng2SearchPipeModule.ctorParameters = () => [];
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](Ng2SearchPipeModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgModule,
        args: [{
                declarations: [Ng2SearchPipe],
                exports: [Ng2SearchPipe]
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](Ng2SearchPipeModule, { declarations: [Ng2SearchPipe], exports: [Ng2SearchPipe] }); })();

/**
 * Generated bundle index. Do not edit.
 */





/***/ }),

/***/ 8220:
/*!************************************************************************!*\
  !*** ./src/app/user-transaction/user-transaction.page.scss?ngResource ***!
  \************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ1c2VyLXRyYW5zYWN0aW9uLnBhZ2Uuc2NzcyJ9 */";

/***/ }),

/***/ 3919:
/*!************************************************************************!*\
  !*** ./src/app/user-transaction/user-transaction.page.html?ngResource ***!
  \************************************************************************/
/***/ ((module) => {

module.exports = "<ion-content [fullscreen]=\"true\">\n  <ion-toolbar color=\"primary\">\n    <!-- <ion-buttons slot=\"start\">\n     <ion-menu-button *ngIf=\"!back\"></ion-menu-button>\n     <ion-back-button *ngIf=\"back\" defaultHref=\"/home\"></ion-back-button>\n    </ion-buttons> -->\n    <ion-buttons slot=\"start\">\n        <ion-back-button defaultHref=\"home\" style=\"color: black;\"></ion-back-button>\n      </ion-buttons>\n      <ion-title style=\"color: black;\"> User Transaction </ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button fill=\"clear\" (click)=\"ngOnInit()\"> <i class=\"fas fa-sync-alt\" style=\"font-size: large; color: black;\"  aria-hidden=\"true\"></i> </ion-button>\n    <ion-button fill=\"clear\" (click)=\"deleteUser(id)\"><i class=\"fas fa-trash\" style=\"font-size: large; color: black;\"></i>  </ion-button>\n     <ion-button fill=\"clear\"  [routerLink]=\"['/edittransaction',id]\"><i class=\"fas fa-edit\" style=\"font-size: large; color: black;\"></i> </ion-button>\n     </ion-buttons>\n  </ion-toolbar>\n  <ion-grid class=\"main-header\">\n    <div align=\"center\">\n      <ion-avatar>\n        <img src=\"../../assets/userpng.png\" />\n      </ion-avatar>\n    </div>\n  </ion-grid>\n  <ion-row class=\"ion-padding-horizontal\">\n    <ion-col size=\"6\">\n      <ion-item lines=\"none\" class=\"ion-text-center\">\n        <ion-icon name=\"person\" color=\"primary\"></ion-icon>\n        <ion-label>\n           {{User.userName}}\n          <p>User Name</p>\n        </ion-label>\n      </ion-item>\n    </ion-col>\n    <ion-col size=\"6\">\n      <ion-item lines=\"none\" class=\"ion-text-center\">\n        <ion-icon name=\"car\" color=\"primary\"></ion-icon>\n        <ion-label>\n          {{User.autoNumber}}\n          <p> Auto Number</p>\n        </ion-label>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n  <div class=\"btn-group\" style=\"width: 100%;\" role=\"group\" aria-label=\"Basic example\">\n    <button type=\"button\" [ngStyle]=\"{'background-color': !active? 'yellow' : '#FFFE67', 'color':'black'}\" style=\"width: 50%;\" (click)=\"activecolor()\" class=\"btn btn-secondary\">User Details</button>\n    <button type=\"button\" [ngStyle]=\"{'background-color': !active? 'yellow' : '#FFFE67', 'color':'black'}\"  style=\"width: 50%;\" (click)=\"activecolor()\" class=\"btn btn-secondary\">User Transactions</button>\n  </div>  \n  <ion-list lines=\"full\">\n    <ion-item>\n      <ion-label>\n        <ion-text>Transaction Id</ion-text>\n        <p><ion-text color=\"dark\">{{User.transactionId}}</ion-text></p>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-text>Place</ion-text>\n        <p><ion-text color=\"dark\">{{User.place}}</ion-text></p>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-text>AmountRecived</ion-text>\n        <p><ion-text color=\"dark\">{{User.amountRecived}}</ion-text></p>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-text>RecivedBy</ion-text>\n        <p><ion-text color=\"dark\">{{User.recivedBy}}</ion-text></p>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-text>Recived Date</ion-text>\n        <p><ion-text color=\"dark\">{{User.recivedDate | date:'shortDate'}}</ion-text></p>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-text>GienBy</ion-text>\n        <p><ion-text color=\"dark\">{{User.gienBy}}</ion-text></p>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-text>BalanceAmount</ion-text>\n        <p><ion-text color=\"dark\">{{User.userBalanceAmount}}</ion-text></p>\n      </ion-label>\n    </ion-item>\n  </ion-list>\n\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_user-transaction_user-transaction_module_ts.js.map