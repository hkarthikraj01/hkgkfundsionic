"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_edittransaction_edittransaction_module_ts"],{

/***/ 8624:
/*!*******************************************************************!*\
  !*** ./src/app/edittransaction/edittransaction-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EdittransactionPageRoutingModule": () => (/* binding */ EdittransactionPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _edittransaction_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./edittransaction.page */ 8088);




const routes = [
    {
        path: ':id',
        component: _edittransaction_page__WEBPACK_IMPORTED_MODULE_0__.EdittransactionPage
    }
];
let EdittransactionPageRoutingModule = class EdittransactionPageRoutingModule {
};
EdittransactionPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], EdittransactionPageRoutingModule);



/***/ }),

/***/ 7125:
/*!***********************************************************!*\
  !*** ./src/app/edittransaction/edittransaction.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EdittransactionPageModule": () => (/* binding */ EdittransactionPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _edittransaction_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./edittransaction-routing.module */ 8624);
/* harmony import */ var _edittransaction_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edittransaction.page */ 8088);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ 8784);








let EdittransactionPageModule = class EdittransactionPageModule {
};
EdittransactionPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpClientModule,
            _edittransaction_routing_module__WEBPACK_IMPORTED_MODULE_0__.EdittransactionPageRoutingModule
        ],
        declarations: [_edittransaction_page__WEBPACK_IMPORTED_MODULE_1__.EdittransactionPage]
    })
], EdittransactionPageModule);



/***/ }),

/***/ 8088:
/*!*********************************************************!*\
  !*** ./src/app/edittransaction/edittransaction.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EdittransactionPage": () => (/* binding */ EdittransactionPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _edittransaction_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./edittransaction.page.html?ngResource */ 281);
/* harmony import */ var _edittransaction_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edittransaction.page.scss?ngResource */ 8172);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _class_transaction__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../class/transaction */ 8407);
/* harmony import */ var _service_transaction_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../service/transaction.service */ 1263);









let EdittransactionPage = class EdittransactionPage {
    constructor(API, actRoute, router, fb, alertCtrl) {
        this.API = API;
        this.actRoute = actRoute;
        this.router = router;
        this.fb = fb;
        this.alertCtrl = alertCtrl;
        this.transaction = new _class_transaction__WEBPACK_IMPORTED_MODULE_2__.Transaction();
        this.date = new Date();
    }
    ngOnInit() {
        this.transactionId = this.actRoute.snapshot.paramMap.get('id');
        this.API.getSingleUser(this.transactionId).subscribe(res => {
            this.transaction = res;
            this.updateTransaction = this.fb.group({
                id: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.transaction.id),
                transactionId: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.transaction.transactionId),
                userName: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.transaction.userName, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
                place: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.transaction.place, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
                autoNumber: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.transaction.autoNumber, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
                amountRecived: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.transaction.amountRecived, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
                recivedBy: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.transaction.recivedBy, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
                recivedDate: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.transaction.recivedDate, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
                userBalanceAmount: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.transaction.userBalanceAmount, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
                gienBy: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.transaction.gienBy, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
            });
            this.date = this.transaction.recivedDate;
        });
        this.updateTransaction = this.fb.group({
            id: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.transaction.id),
            transactionId: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.transaction.transactionId),
            userName: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.transaction.userName, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
            place: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.transaction.place, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
            autoNumber: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.transaction.autoNumber, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
            amountRecived: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.transaction.amountRecived, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
            //
            recivedBy: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.transaction.recivedBy, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
            recivedDate: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.transaction.recivedDate, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
            // 
            userBalanceAmount: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.transaction.userBalanceAmount, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
            //
            gienBy: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.transaction.gienBy, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
            //
        });
        console.log(this.date);
    }
    updateTransactionForm() {
        if (!this.updateTransaction.valid) {
            console.log(this.updateTransaction.value);
            console.log("error");
            return false;
        }
        else {
            console.log(this.updateTransaction.value);
            this.API.updateSingleUser(this.transactionId, this.updateTransaction.value)
                .subscribe((res) => {
                console.log(res);
                this.showAlert(res);
                this.router.navigate(['/viewtransaction/' + this.transactionId]);
            });
        }
    }
    showAlert(res) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                header: 'Alert',
                subHeader: 'Create',
                message: res + ' ' + this.transaction.userName,
                buttons: ['OK']
            });
            yield alert.present();
            const result = yield alert.onDidDismiss();
            console.log(result);
        });
    }
};
EdittransactionPage.ctorParameters = () => [
    { type: _service_transaction_service__WEBPACK_IMPORTED_MODULE_3__.TransactionService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.ActivatedRoute },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.AlertController }
];
EdittransactionPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-edittransaction',
        template: _edittransaction_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_edittransaction_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], EdittransactionPage);



/***/ }),

/***/ 8172:
/*!**********************************************************************!*\
  !*** ./src/app/edittransaction/edittransaction.page.scss?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJlZGl0dHJhbnNhY3Rpb24ucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 281:
/*!**********************************************************************!*\
  !*** ./src/app/edittransaction/edittransaction.page.html?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "<ion-content [fullscreen]=\"true\">\n  <ion-header>\n    <ion-toolbar class=\"ios hydrated\" color=\"primary\">\n      <ion-buttons slot=\"start\">\n        <ion-back-button defaultHref=\"home\" style=\"color: black;\"></ion-back-button>\n      </ion-buttons>\n      <ion-title class=\"ios title-ios hydrated\" style=\"color: black;\">Edit UserTransaction</ion-title>\n    </ion-toolbar>\n  </ion-header>\n  <ion-grid class=\"main-header\">\n    <div align=\"center\">\n      <ion-avatar>\n        <img src=\"../../assets/userpng.png\" />\n      </ion-avatar>\n    </div>\n  </ion-grid>\n  <form [formGroup]=\"updateTransaction\" (ngSubmit)=\"updateTransactionForm()\">\n  <ion-row class=\"ion-padding-horizontal\">\n    <ion-col size=\"6\">\n      <ion-item lines=\"none\" class=\"ion-text-center\">\n        <!-- <ion-icon name=\"water\" color=\"primary\"></ion-icon> -->\n        <ion-label>\n          <ion-label position=\"floating\">userName</ion-label>\n          <ion-input formControlName=\"userName\" placeholder=\"userName\" type=\"text\" required></ion-input>\n        </ion-label>\n      </ion-item>\n    </ion-col>\n    <ion-col size=\"6\">\n      <ion-item lines=\"none\" class=\"ion-text-center\">\n        <!-- <ion-icon name=\"trophy\" color=\"primary\"></ion-icon> -->\n        <ion-label>\n          <ion-label position=\"floating\">Auto Number</ion-label>\n          <ion-input formControlName=\"autoNumber\" type=\"text\" placeholder=\"autoNumber\" required></ion-input>\n        </ion-label>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n\n  <ion-list lines=\"full\">\n    <ion-item>\n      <ion-label>\n        <ion-label position=\"floating\">Place</ion-label>\n        <ion-input formControlName=\"place\" type=\"text\" required></ion-input>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-label position=\"floating\">Amount Recived</ion-label>\n        <ion-input formControlName=\"amountRecived\" type=\"number\" required></ion-input>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-label position=\"floating\">Recived By</ion-label>\n        <ion-input formControlName=\"recivedBy\" type=\"text\" required></ion-input>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-label position=\"floating\">Recived Date {{date | date:'shortDate'}}</ion-label>\n        <ion-input formControlName=\"recivedDate\" type=\"date\" required></ion-input>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-label position=\"floating\">userBalanceAmount</ion-label>\n        <ion-input formControlName=\"userBalanceAmount\" type=\"number\" required></ion-input>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-label position=\"floating\">gienBy</ion-label>\n        <ion-input formControlName=\"gienBy\" type=\"text\" required></ion-input>\n      </ion-label>\n    </ion-item>\n   \n      <ion-col>\n        <ion-button type=\"submit\" color=\"primary\" shape=\"full\" expand=\"block\">Update</ion-button>\n      </ion-col>\n  </ion-list>\n</form>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_edittransaction_edittransaction_module_ts.js.map