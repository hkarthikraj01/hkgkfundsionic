"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_transactions_transactions_module_ts"],{

/***/ 7052:
/*!*************************************************************!*\
  !*** ./src/app/transactions/transactions-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TransactionsPageRoutingModule": () => (/* binding */ TransactionsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _transactions_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./transactions.page */ 7138);




const routes = [
    {
        path: '',
        component: _transactions_page__WEBPACK_IMPORTED_MODULE_0__.TransactionsPage
    }
];
let TransactionsPageRoutingModule = class TransactionsPageRoutingModule {
};
TransactionsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], TransactionsPageRoutingModule);



/***/ }),

/***/ 5528:
/*!*****************************************************!*\
  !*** ./src/app/transactions/transactions.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TransactionsPageModule": () => (/* binding */ TransactionsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _transactions_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./transactions-routing.module */ 7052);
/* harmony import */ var _transactions_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./transactions.page */ 7138);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common/http */ 8784);
/* harmony import */ var ng2_search_filter__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ng2-search-filter */ 9991);









let TransactionsPageModule = class TransactionsPageModule {
};
TransactionsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _angular_common_http__WEBPACK_IMPORTED_MODULE_8__.HttpClientModule,
            _transactions_routing_module__WEBPACK_IMPORTED_MODULE_0__.TransactionsPageRoutingModule,
            ng2_search_filter__WEBPACK_IMPORTED_MODULE_2__.Ng2SearchPipeModule
        ],
        declarations: [_transactions_page__WEBPACK_IMPORTED_MODULE_1__.TransactionsPage]
    })
], TransactionsPageModule);



/***/ }),

/***/ 7138:
/*!***************************************************!*\
  !*** ./src/app/transactions/transactions.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TransactionsPage": () => (/* binding */ TransactionsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _transactions_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./transactions.page.html?ngResource */ 3875);
/* harmony import */ var _transactions_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./transactions.page.scss?ngResource */ 8330);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _service_transaction_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../service/transaction.service */ 1263);
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! xlsx */ 4126);







let TransactionsPage = class TransactionsPage {
    constructor(API, route) {
        this.API = API;
        this.route = route;
        this.transaction = [];
        this.Filter = "";
    }
    ngOnInit() {
        this.API.getAllUser().subscribe(res => {
            console.log(res);
            this.transaction = res;
        });
    }
    //edittransaction
    viewProfile(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.route.navigateByUrl("/viewtransaction/" + id);
        });
    }
    exportexcel() {
        /* pass here the table id */
        const workBook = xlsx__WEBPACK_IMPORTED_MODULE_4__.utils.book_new(); // create a new blank book
        const workSheet = xlsx__WEBPACK_IMPORTED_MODULE_4__.utils.json_to_sheet(this.transaction);
        xlsx__WEBPACK_IMPORTED_MODULE_4__.utils.book_append_sheet(workBook, workSheet, 'Users Transaction List'); // add the worksheet to the book
        xlsx__WEBPACK_IMPORTED_MODULE_4__.writeFile(workBook, 'All Transaction List - ' + new Date + '.xlsx');
    }
};
TransactionsPage.ctorParameters = () => [
    { type: _service_transaction_service__WEBPACK_IMPORTED_MODULE_2__.TransactionService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router }
];
TransactionsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-transactions',
        template: _transactions_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_transactions_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], TransactionsPage);



/***/ }),

/***/ 8330:
/*!****************************************************************!*\
  !*** ./src/app/transactions/transactions.page.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "ion-card {\n  --background: yellow;\n}\nion-card p {\n  font-weight: 300;\n}\nion-card ion-card-subtitle {\n  font-size: large;\n  font-weight: bold;\n  color: black;\n  padding-bottom: 2px;\n}\nion-card .date {\n  font-weight: bold;\n  color: black;\n}\nion-card .icon {\n  font-size: 25px;\n  color: black;\n  padding-left: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRyYW5zYWN0aW9ucy5wYWdlLnNjc3MiLCIuLlxcLi5cXC4uXFwuLlxcLi5cXElvbmljJTIwUHJvamVjdFxcaGtna2Z1bmRzXFxzcmNcXGFwcFxcdHJhbnNhY3Rpb25zXFx0cmFuc2FjdGlvbnMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksb0JBQUE7QUNDSjtBRENJO0VBQ0MsZ0JBQUE7QUNDTDtBRENJO0VBQ0ksZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtBQ0NSO0FEQ0k7RUFDSSxpQkFBQTtFQUNBLFlBQUE7QUNDUjtBRENJO0VBQ0ksZUFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQ0NSIiwiZmlsZSI6InRyYW5zYWN0aW9ucy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY2FyZHtcclxuICAgIC0tYmFja2dyb3VuZCA6IHllbGxvdztcclxuICBcclxuICAgIHB7XHJcbiAgICAgZm9udC13ZWlnaHQ6IDMwMDtcclxuICAgIH1cclxuICAgIGlvbi1jYXJkLXN1YnRpdGxle1xyXG4gICAgICAgIGZvbnQtc2l6ZTogbGFyZ2U7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICAgICAgY29sb3I6IGJsYWNrO1xyXG4gICAgICAgIHBhZGRpbmctYm90dG9tOiAycHg7XHJcbiAgICB9XHJcbiAgICAuZGF0ZXtcclxuICAgICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgICAgICBjb2xvcjogYmxhY2s7XHJcbiAgICB9XHJcbiAgICAuaWNvbntcclxuICAgICAgICBmb250LXNpemU6IDI1cHg7XHJcbiAgICAgICAgY29sb3I6IGJsYWNrO1xyXG4gICAgICAgIHBhZGRpbmctbGVmdDogMTBweDtcclxuICAgIH1cclxuICB9IiwiaW9uLWNhcmQge1xuICAtLWJhY2tncm91bmQ6IHllbGxvdztcbn1cbmlvbi1jYXJkIHAge1xuICBmb250LXdlaWdodDogMzAwO1xufVxuaW9uLWNhcmQgaW9uLWNhcmQtc3VidGl0bGUge1xuICBmb250LXNpemU6IGxhcmdlO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgY29sb3I6IGJsYWNrO1xuICBwYWRkaW5nLWJvdHRvbTogMnB4O1xufVxuaW9uLWNhcmQgLmRhdGUge1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgY29sb3I6IGJsYWNrO1xufVxuaW9uLWNhcmQgLmljb24ge1xuICBmb250LXNpemU6IDI1cHg7XG4gIGNvbG9yOiBibGFjaztcbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xufSJdfQ== */";

/***/ }),

/***/ 3875:
/*!****************************************************************!*\
  !*** ./src/app/transactions/transactions.page.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "<ion-toolbar color=\"primary\">\n  <ion-buttons slot=\"start\">\n   <ion-menu-button *ngIf=\"!back\" style=\"color: black;\"></ion-menu-button>\n   <ion-title style=\"color: black;\"> HKGK Funds </ion-title>\n   <ion-back-button *ngIf=\"back\" defaultHref=\"/home\"></ion-back-button>\n  </ion-buttons>\n  <ion-buttons slot=\"end\">\n    <ion-button fill=\"clear\" (click)=\"exportexcel()\" > <i class=\"fa-solid fa-file-export\" style=\"font-size: large; color: black;\"></i> </ion-button>\n    <ion-button fill=\"clear\" (click)=\"ngOnInit()\" > <i class=\"fas fa-sync-alt\" style=\"font-size: large; color: black;\"  aria-hidden=\"true\"></i> </ion-button>\n   </ion-buttons>\n</ion-toolbar>\n<ion-content [fullscreen]=\"true\">\n  <ion-searchbar style=\"color: black;\" color=\"primary\" [(ngModel)]=\"Filter\"></ion-searchbar>\n  <ion-card *ngFor=\"let item of transaction | filter:Filter\" (click)=\"viewProfile(item.transactionId)\" class=\"ion-margin\">\n    <ion-card-header>     \n      <ion-card-subtitle>\n        {{item.recivedBy}}\n      </ion-card-subtitle>\n      <ion-item>\n        <ion-col size=\"8\"><ion-label>{{item.userName}} </ion-label></ion-col>\n        <ion-col size=\"4\"><ion-label>₹{{ item.amountRecived}}</ion-label></ion-col>       \n      </ion-item>\n    </ion-card-header>\n    <ion-card-content>\n     <ion-label>Payed On {{item.recivedDate | date:'fullDate'}} <ion-icon class=\"icon\" name=\"arrow-redo-outline\"></ion-icon></ion-label>\n  \n    </ion-card-content>\n  </ion-card>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_transactions_transactions_module_ts.js.map