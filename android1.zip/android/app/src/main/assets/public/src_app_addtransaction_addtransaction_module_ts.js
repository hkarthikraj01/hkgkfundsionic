"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_addtransaction_addtransaction_module_ts"],{

/***/ 8668:
/*!*****************************************************************!*\
  !*** ./src/app/addtransaction/addtransaction-routing.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddtransactionPageRoutingModule": () => (/* binding */ AddtransactionPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _addtransaction_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./addtransaction.page */ 8599);




const routes = [
    {
        path: '',
        component: _addtransaction_page__WEBPACK_IMPORTED_MODULE_0__.AddtransactionPage
    }
];
let AddtransactionPageRoutingModule = class AddtransactionPageRoutingModule {
};
AddtransactionPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AddtransactionPageRoutingModule);



/***/ }),

/***/ 2576:
/*!*********************************************************!*\
  !*** ./src/app/addtransaction/addtransaction.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddtransactionPageModule": () => (/* binding */ AddtransactionPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _addtransaction_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./addtransaction-routing.module */ 8668);
/* harmony import */ var _addtransaction_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./addtransaction.page */ 8599);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ 8784);








let AddtransactionPageModule = class AddtransactionPageModule {
};
AddtransactionPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpClientModule,
            _addtransaction_routing_module__WEBPACK_IMPORTED_MODULE_0__.AddtransactionPageRoutingModule
        ],
        declarations: [_addtransaction_page__WEBPACK_IMPORTED_MODULE_1__.AddtransactionPage]
    })
], AddtransactionPageModule);



/***/ }),

/***/ 8599:
/*!*******************************************************!*\
  !*** ./src/app/addtransaction/addtransaction.page.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddtransactionPage": () => (/* binding */ AddtransactionPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _addtransaction_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./addtransaction.page.html?ngResource */ 5681);
/* harmony import */ var _addtransaction_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./addtransaction.page.scss?ngResource */ 5732);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _service_transaction_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../service/transaction.service */ 1263);








let AddtransactionPage = class AddtransactionPage {
    constructor(API, actRoute, router, fb, alertCtrl) {
        this.API = API;
        this.actRoute = actRoute;
        this.router = router;
        this.fb = fb;
        this.alertCtrl = alertCtrl;
    }
    ngOnInit() {
        this.addTransaction = this.fb.group({
            //id:new FormControl(this.user.id),
            // userId : new FormControl(this.userId,[Validators.required,Validators.minLength(1)]),
            userName: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl('', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.minLength(1)]),
            place: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl('', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.minLength(1)]),
            autoNumber: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl('', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.minLength(1)]),
            amountRecived: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl('', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.minLength(1)]),
            //
            recivedBy: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl('', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.minLength(1)]),
            recivedDate: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl('', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.minLength(1)]),
            // 
            userBalanceAmount: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl('', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.minLength(1)]),
            //
            gienBy: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl('', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.minLength(1)]),
            //
        });
    }
    addTransactionForm() {
        if (!this.addTransaction.valid) {
            console.log(this.addTransaction.value);
            console.log("error");
            return false;
        }
        else {
            console.log(this.addTransaction.value);
            this.API.Register(this.addTransaction.value)
                .subscribe((res) => {
                console.log(res);
                this.showAlert(res);
                this.router.navigate(['transactions']);
            });
            this.router.navigate(['transactions']);
        }
    }
    showAlert(res) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                header: 'Alert',
                subHeader: 'Create',
                message: res,
                buttons: ['OK']
            });
            yield alert.present();
            const result = yield alert.onDidDismiss();
            console.log(result);
        });
    }
};
AddtransactionPage.ctorParameters = () => [
    { type: _service_transaction_service__WEBPACK_IMPORTED_MODULE_2__.TransactionService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormBuilder },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController }
];
AddtransactionPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-addtransaction',
        template: _addtransaction_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_addtransaction_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AddtransactionPage);



/***/ }),

/***/ 5732:
/*!********************************************************************!*\
  !*** ./src/app/addtransaction/addtransaction.page.scss?ngResource ***!
  \********************************************************************/
/***/ ((module) => {

module.exports = ".native-input[type=date]::-webkit-calendar-picker-indicator {\n  filter: invert(1);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFkZHRyYW5zYWN0aW9uLnBhZ2Uuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFwuLlxcSW9uaWMlMjBQcm9qZWN0XFxoa2drZnVuZHNcXHNyY1xcYXBwXFxhZGR0cmFuc2FjdGlvblxcYWRkdHJhbnNhY3Rpb24ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksaUJBQUE7QUNDSiIsImZpbGUiOiJhZGR0cmFuc2FjdGlvbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubmF0aXZlLWlucHV0W3R5cGU9ZGF0ZV06Oi13ZWJraXQtY2FsZW5kYXItcGlja2VyLWluZGljYXRvciB7XHJcbiAgICBmaWx0ZXI6IGludmVydCgxKTtcclxuICB9IiwiLm5hdGl2ZS1pbnB1dFt0eXBlPWRhdGVdOjotd2Via2l0LWNhbGVuZGFyLXBpY2tlci1pbmRpY2F0b3Ige1xuICBmaWx0ZXI6IGludmVydCgxKTtcbn0iXX0= */";

/***/ }),

/***/ 5681:
/*!********************************************************************!*\
  !*** ./src/app/addtransaction/addtransaction.page.html?ngResource ***!
  \********************************************************************/
/***/ ((module) => {

module.exports = "<ion-content [fullscreen]=\"true\">\n  <ion-header>\n    <ion-toolbar class=\"ios hydrated\" color=\"primary\">\n      <ion-buttons slot=\"start\">\n        <ion-back-button defaultHref=\"home\" style=\"color: black;\"></ion-back-button>\n      </ion-buttons>\n      <ion-title class=\"ios title-ios hydrated\" style=\"color: black;\">Add UserTransaction</ion-title>\n    </ion-toolbar>\n  </ion-header>\n  <ion-grid class=\"main-header\">\n    <div align=\"center\">\n      <ion-avatar>\n        <img src=\"../../assets/userpng.png\" />\n      </ion-avatar>\n    </div>\n  </ion-grid>\n  <form [formGroup]=\"addTransaction\" (ngSubmit)=\"addTransactionForm()\">\n  <ion-row class=\"ion-padding-horizontal\">\n    <ion-col size=\"6\">\n      <ion-item lines=\"none\" class=\"ion-text-center\">\n        <!-- <ion-icon name=\"water\" color=\"primary\"></ion-icon> -->\n        <ion-label>\n          <ion-label position=\"floating\">userName</ion-label>\n          <ion-input formControlName=\"userName\" placeholder=\"userName\" type=\"text\" required></ion-input>\n        </ion-label>\n      </ion-item>\n    </ion-col>\n    <ion-col size=\"6\">\n      <ion-item lines=\"none\" class=\"ion-text-center\">\n        <!-- <ion-icon name=\"trophy\" color=\"primary\"></ion-icon> -->\n        <ion-label>\n          <ion-label position=\"floating\">Auto Number</ion-label>\n          <ion-input formControlName=\"autoNumber\" type=\"text\" placeholder=\"autoNumber\" required></ion-input>\n        </ion-label>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n\n  <ion-list lines=\"full\">\n    <ion-item>\n      <ion-label>\n        <ion-label position=\"floating\">Place</ion-label>\n        <ion-input formControlName=\"place\" type=\"text\" required></ion-input>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-label position=\"floating\">Amount Recived</ion-label>\n        <ion-input formControlName=\"amountRecived\" type=\"number\" required></ion-input>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-label position=\"floating\">Recived By</ion-label>\n        <ion-input formControlName=\"recivedBy\" type=\"text\" required></ion-input>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-label position=\"floating\">Recived Date</ion-label>\n        <ion-input formControlName=\"recivedDate\" color=\"primary\" type=\"date\" required></ion-input>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-label position=\"floating\">userBalanceAmount</ion-label>\n        <ion-input formControlName=\"userBalanceAmount\" type=\"number\" required></ion-input>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-label position=\"floating\">gienBy</ion-label>\n        <ion-input formControlName=\"gienBy\" type=\"text\" required></ion-input>\n      </ion-label>\n    </ion-item>\n   <br>\n      <ion-col>\n        <ion-button type=\"submit\" color=\"primary\" shape=\"full\" expand=\"block\">Add</ion-button>\n      </ion-col>\n  </ion-list>\n</form>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_addtransaction_addtransaction_module_ts.js.map