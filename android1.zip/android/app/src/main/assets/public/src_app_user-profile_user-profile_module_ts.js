"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_user-profile_user-profile_module_ts"],{

/***/ 5030:
/*!*************************************************************!*\
  !*** ./src/app/user-profile/user-profile-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserProfilePageRoutingModule": () => (/* binding */ UserProfilePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _user_profile_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./user-profile.page */ 5058);




const routes = [
    {
        path: ':id',
        component: _user_profile_page__WEBPACK_IMPORTED_MODULE_0__.UserProfilePage
    }
];
let UserProfilePageRoutingModule = class UserProfilePageRoutingModule {
};
UserProfilePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], UserProfilePageRoutingModule);



/***/ }),

/***/ 7582:
/*!*****************************************************!*\
  !*** ./src/app/user-profile/user-profile.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserProfilePageModule": () => (/* binding */ UserProfilePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _user_profile_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./user-profile-routing.module */ 5030);
/* harmony import */ var _user_profile_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./user-profile.page */ 5058);
/* harmony import */ var ng2_search_filter__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ng2-search-filter */ 9991);








let UserProfilePageModule = class UserProfilePageModule {
};
UserProfilePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _user_profile_routing_module__WEBPACK_IMPORTED_MODULE_0__.UserProfilePageRoutingModule,
            ng2_search_filter__WEBPACK_IMPORTED_MODULE_2__.Ng2SearchPipeModule
        ],
        declarations: [_user_profile_page__WEBPACK_IMPORTED_MODULE_1__.UserProfilePage]
    })
], UserProfilePageModule);



/***/ }),

/***/ 5058:
/*!***************************************************!*\
  !*** ./src/app/user-profile/user-profile.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserProfilePage": () => (/* binding */ UserProfilePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _user_profile_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./user-profile.page.html?ngResource */ 3444);
/* harmony import */ var _user_profile_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./user-profile.page.scss?ngResource */ 2349);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _class_user__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../class/user */ 3850);
/* harmony import */ var _service_transaction_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../service/transaction.service */ 1263);
/* harmony import */ var _service_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../service/user.service */ 4981);
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! xlsx */ 4126);










let UserProfilePage = class UserProfilePage {
    constructor(route, API, API2, arouter, router, alertCtrl) {
        this.route = route;
        this.API = API;
        this.API2 = API2;
        this.arouter = arouter;
        this.router = router;
        this.alertCtrl = alertCtrl;
        this.User = new _class_user__WEBPACK_IMPORTED_MODULE_2__.User();
        this.MyTrasaction = [];
        this.active = true;
        this.nonactive = false;
    }
    ngOnInit() {
        this.id = this.arouter.snapshot.paramMap.get("id");
        console.log(this.id);
        this.API.getSingleUser(this.id).subscribe(res => {
            console.log(res);
            this.User = res;
        });
        this.API2.getMyTransaction(this.id).subscribe(res => {
            console.log(res);
            this.MyTrasaction = res;
        });
    }
    deleteUser(id) {
        this.API.deleteSingleUser(this.id).subscribe(res => {
            console.log(res);
            this.showAlert(res);
            this.router.navigateByUrl("");
        });
    }
    activecolor() {
        // debugger
        if (!this.active) {
            this.active = !this.active;
            this.nonactive = !this.nonactive;
        }
        console.log(this.active);
    }
    nonactiveColor() {
        if (!this.nonactive) {
            this.active = !this.active;
            this.nonactive = !this.nonactive;
        }
    }
    showAlert(res) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                header: 'Alert',
                subHeader: 'Delete',
                message: res + ' ' + this.User.userName,
                buttons: ['OK']
            });
            yield alert.present();
            const result = yield alert.onDidDismiss();
            console.log(result);
        });
    }
    viewProfile(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            this.route.navigateByUrl("/viewtransaction/" + id);
        });
    }
    exportexcel() {
        /* pass here the table id */
        const workBook = xlsx__WEBPACK_IMPORTED_MODULE_6__.utils.book_new(); // create a new blank book
        const workSheet = xlsx__WEBPACK_IMPORTED_MODULE_6__.utils.json_to_sheet(this.MyTrasaction);
        xlsx__WEBPACK_IMPORTED_MODULE_6__.utils.book_append_sheet(workBook, workSheet, this.User.userName + ' Transaction List'); // add the worksheet to the book
        xlsx__WEBPACK_IMPORTED_MODULE_6__.writeFile(workBook, this.User.userName + ' Transaction List - ' + new Date + '.xlsx');
    }
};
UserProfilePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router },
    { type: _service_user_service__WEBPACK_IMPORTED_MODULE_4__.UserService },
    { type: _service_transaction_service__WEBPACK_IMPORTED_MODULE_3__.TransactionService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.AlertController }
];
UserProfilePage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-user-profile',
        template: _user_profile_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_user_profile_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], UserProfilePage);



/***/ }),

/***/ 2349:
/*!****************************************************************!*\
  !*** ./src/app/user-profile/user-profile.page.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "ion-card {\n  --background: white;\n}\nion-card p {\n  font-weight: 300;\n}\nion-card ion-card-subtitle {\n  font-size: large;\n  font-weight: bold;\n  color: black;\n  padding-bottom: 2px;\n}\nion-card .date {\n  font-weight: bold;\n  color: black;\n}\nion-card .icon {\n  font-size: 25px;\n  color: black;\n  padding-left: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZXItcHJvZmlsZS5wYWdlLnNjc3MiLCIuLlxcLi5cXC4uXFwuLlxcLi5cXElvbmljJTIwUHJvamVjdFxcaGtna2Z1bmRzXFxzcmNcXGFwcFxcdXNlci1wcm9maWxlXFx1c2VyLXByb2ZpbGUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUJBQUE7QUNDSjtBRENJO0VBQ0MsZ0JBQUE7QUNDTDtBRENJO0VBQ0ksZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtBQ0NSO0FEQ0k7RUFDSSxpQkFBQTtFQUNBLFlBQUE7QUNDUjtBRENJO0VBQ0ksZUFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQ0NSIiwiZmlsZSI6InVzZXItcHJvZmlsZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY2FyZHtcclxuICAgIC0tYmFja2dyb3VuZCA6IHdoaXRlO1xyXG4gIFxyXG4gICAgcHtcclxuICAgICBmb250LXdlaWdodDogMzAwO1xyXG4gICAgfVxyXG4gICAgaW9uLWNhcmQtc3VidGl0bGV7XHJcbiAgICAgICAgZm9udC1zaXplOiBsYXJnZTtcclxuICAgICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgICAgICBjb2xvcjogYmxhY2s7XHJcbiAgICAgICAgcGFkZGluZy1ib3R0b206IDJweDtcclxuICAgIH1cclxuICAgIC5kYXRle1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgICAgIGNvbG9yOiBibGFjaztcclxuICAgIH1cclxuICAgIC5pY29ue1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMjVweDtcclxuICAgICAgICBjb2xvcjogYmxhY2s7XHJcbiAgICAgICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xyXG4gICAgfVxyXG4gIH0iLCJpb24tY2FyZCB7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG59XG5pb24tY2FyZCBwIHtcbiAgZm9udC13ZWlnaHQ6IDMwMDtcbn1cbmlvbi1jYXJkIGlvbi1jYXJkLXN1YnRpdGxlIHtcbiAgZm9udC1zaXplOiBsYXJnZTtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGNvbG9yOiBibGFjaztcbiAgcGFkZGluZy1ib3R0b206IDJweDtcbn1cbmlvbi1jYXJkIC5kYXRlIHtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGNvbG9yOiBibGFjaztcbn1cbmlvbi1jYXJkIC5pY29uIHtcbiAgZm9udC1zaXplOiAyNXB4O1xuICBjb2xvcjogYmxhY2s7XG4gIHBhZGRpbmctbGVmdDogMTBweDtcbn0iXX0= */";

/***/ }),

/***/ 3444:
/*!****************************************************************!*\
  !*** ./src/app/user-profile/user-profile.page.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "<ion-content [fullscreen]=\"true\">\n\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n     <ion-menu-button *ngIf=\"!back\" style=\"color: black;\"></ion-menu-button>\n     <ion-back-button *ngIf=\"back\" defaultHref=\"/home\"></ion-back-button>\n    </ion-buttons>\n    <ion-title style=\"color: black;\"> User Details </ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button fill=\"clear\" (click)=\"exportexcel()\" > <i class=\"fa-solid fa-file-export\" style=\"font-size: large; color: black;\"></i> </ion-button>\n      <ion-button fill=\"clear\" (click)=\"ngOnInit()\"> <i class=\"fas fa-sync-alt\" style=\"font-size: large; color: black;\"  aria-hidden=\"true\"></i> </ion-button>\n    <ion-button fill=\"clear\" (click)=\"deleteUser(id)\"><i class=\"fas fa-trash\" style=\"font-size: large; color: black;\"></i>  </ion-button>\n     <ion-button fill=\"clear\"  [routerLink]=\"['/edituserprofile',id]\"><i class=\"fas fa-edit\" style=\"font-size: large; color: black;\"></i> </ion-button>\n     </ion-buttons>\n  </ion-toolbar>\n  <ion-grid class=\"main-header\">\n    <div align=\"center\">\n      <ion-avatar>\n        <img src=\"../../assets/userpng.png\" />\n      </ion-avatar>\n    </div>\n  </ion-grid>\n\n  <ion-row class=\"ion-padding-horizontal\">\n    <ion-col size=\"6\">\n      <ion-item lines=\"none\" class=\"ion-text-center\">\n        <ion-icon name=\"cash\" color=\"primary\"></ion-icon>\n        <ion-label>\n           {{User.userBalanceAmount}}\n          <p>Balance Amount</p>\n        </ion-label>\n      </ion-item>\n    </ion-col>\n    <ion-col size=\"6\">\n      <ion-item lines=\"none\" class=\"ion-text-center\">\n        <ion-icon name=\"car\" color=\"primary\"></ion-icon>\n        <ion-label>\n          {{User.autoNumber}}\n          <p> Auto Number</p>\n        </ion-label>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n  <div class=\"btn-group\" style=\"width: 100%;\" role=\"group\" aria-label=\"Basic example\">\n    <button type=\"button\" [ngStyle]=\"{'background-color': active? 'yellow' : '#FFFE67', 'color':'black'}\" style=\"width: 50%;\" (click)=\"activecolor()\" class=\"btn btn-secondary\">User Details</button>\n    <button type=\"button\" [ngStyle]=\"{'background-color': nonactive? 'yellow' : '#FFFE67', 'color':'black'}\"  style=\"width: 50%;\" (click)=\"nonactiveColor()\" class=\"btn btn-secondary\">User Transactions</button>\n  </div>  \n  <ion-list lines=\"full\" *ngIf=\"active\">\n    <ion-item>\n      <ion-label>\n        <ion-text>Name</ion-text>\n        <p><ion-text color=\"dark\">{{User.userName}}</ion-text></p>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-text>Phone</ion-text>\n        <p><ion-text color=\"dark\">{{User.userMobileNumber}}</ion-text></p>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-text>Family Numbers Name</ion-text>\n        <p><ion-text color=\"dark\">{{User.familyNumberNames}}</ion-text></p>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-text>Id Proof</ion-text>\n        <p><ion-text color=\"dark\">{{User.identityProof}}</ion-text></p>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-text>Address</ion-text>\n        <p><ion-text color=\"dark\">{{User.userAddress}}</ion-text></p>\n      </ion-label>\n    </ion-item>\n  </ion-list>\n\n  <ion-content *ngIf=\"nonactive\">\n    <ion-searchbar style=\"color: black;\" color=\"secondary\" [(ngModel)]=\"Filter\"></ion-searchbar>\n  <ion-card *ngFor=\"let item of MyTrasaction | filter:Filter\" (click)=\"viewProfile(item.transactionId)\" class=\"ion-margin\">\n    <ion-card-header>     \n      <ion-card-subtitle>\n        {{item.place}}\n      </ion-card-subtitle>\n      <ion-item>\n        <ion-col size=\"8\"><ion-label>{{item.recivedBy}} </ion-label></ion-col>\n        <ion-col size=\"4\"><ion-label>₹ {{ item.amountRecived}}</ion-label></ion-col>       \n      </ion-item>\n    </ion-card-header>\n    <ion-card-content>\n     <ion-label>Payed On {{item.recivedDate | date:'fullDate'}} <ion-icon class=\"icon\" name=\"arrow-redo-outline\"></ion-icon></ion-label>\n  \n    </ion-card-content>\n  </ion-card>  \n  </ion-content>   \n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_user-profile_user-profile_module_ts.js.map