"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_edituserprofile_edituserprofile_module_ts"],{

/***/ 5743:
/*!*******************************************************************!*\
  !*** ./src/app/edituserprofile/edituserprofile-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EdituserprofilePageRoutingModule": () => (/* binding */ EdituserprofilePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _edituserprofile_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./edituserprofile.page */ 490);




const routes = [
    {
        path: ':id',
        component: _edituserprofile_page__WEBPACK_IMPORTED_MODULE_0__.EdituserprofilePage
    }
];
let EdituserprofilePageRoutingModule = class EdituserprofilePageRoutingModule {
};
EdituserprofilePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], EdituserprofilePageRoutingModule);



/***/ }),

/***/ 6078:
/*!***********************************************************!*\
  !*** ./src/app/edituserprofile/edituserprofile.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EdituserprofilePageModule": () => (/* binding */ EdituserprofilePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _edituserprofile_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./edituserprofile-routing.module */ 5743);
/* harmony import */ var _edituserprofile_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edituserprofile.page */ 490);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ 8784);








let EdituserprofilePageModule = class EdituserprofilePageModule {
};
EdituserprofilePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpClientModule,
            _edituserprofile_routing_module__WEBPACK_IMPORTED_MODULE_0__.EdituserprofilePageRoutingModule
        ],
        declarations: [_edituserprofile_page__WEBPACK_IMPORTED_MODULE_1__.EdituserprofilePage]
    })
], EdituserprofilePageModule);



/***/ }),

/***/ 490:
/*!*********************************************************!*\
  !*** ./src/app/edituserprofile/edituserprofile.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EdituserprofilePage": () => (/* binding */ EdituserprofilePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _edituserprofile_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./edituserprofile.page.html?ngResource */ 7657);
/* harmony import */ var _edituserprofile_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edituserprofile.page.scss?ngResource */ 8297);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _class_user__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../class/user */ 3850);
/* harmony import */ var _service_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../service/user.service */ 4981);









let EdituserprofilePage = class EdituserprofilePage {
    constructor(API, actRoute, router, fb, alertCtrl) {
        this.API = API;
        this.actRoute = actRoute;
        this.router = router;
        this.fb = fb;
        this.alertCtrl = alertCtrl;
        this.user = new _class_user__WEBPACK_IMPORTED_MODULE_2__.User();
    }
    ngOnInit() {
        this.userId = this.actRoute.snapshot.paramMap.get('id');
        this.API.getSingleUser(this.userId).subscribe(res => {
            this.user = res;
            this.updateUser = this.fb.group({
                id: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.user.id, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
                userId: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.userId, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
                userName: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.user.userName, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
                userPassword: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.user.userPassword, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
                autoNumber: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.user.autoNumber, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
                userMobileNumber: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.user.userMobileNumber, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
                userTotalAmount: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.user.userTotalAmount, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
                userBalanceAmount: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.user.userBalanceAmount, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
                userAcceptedAmount: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.user.userAcceptedAmount, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
                userProfilePicture: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.user.userProfilePicture, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
                userStatus: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.user.userStatus, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
                role: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.user.role),
                userAddress: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.user.userAddress, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
                identityProof: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.user.identityProof, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
                familyNumberNames: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.user.familyNumberNames, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
            });
        });
        this.updateUser = this.fb.group({
            userId: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.userId, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
            userName: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.user.userName, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
            userPassword: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.user.userPassword, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
            autoNumber: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.user.autoNumber, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
            userMobileNumber: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.user.userMobileNumber, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
            userTotalAmount: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.user.userTotalAmount, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
            userBalanceAmount: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.user.userBalanceAmount, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
            userAcceptedAmount: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.user.userAcceptedAmount, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
            userProfilePicture: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.user.userProfilePicture, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
            userStatus: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.user.userStatus, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
            role: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.user.role, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
            userAddress: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.user.userAddress, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
            identityProof: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.user.identityProof, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
            familyNumberNames: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(this.user.familyNumberNames, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)]),
        });
        console.log(this.userId);
    }
    updateForm() {
        if (!this.updateUser.valid) {
            console.log(this.updateUser.value);
            console.log("error");
            return false;
        }
        else {
            console.log(this.updateUser.value);
            this.API.updateSingleUser(this.userId, this.updateUser.value)
                .subscribe((res) => {
                console.log(res);
                this.showAlert(res);
                this.router.navigate(['/user-profile/' + this.userId]);
            });
        }
    }
    showAlert(res) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                header: 'Alert',
                subHeader: 'Create',
                message: res + ' ' + this.user.userName,
                buttons: ['OK']
            });
            yield alert.present();
            const result = yield alert.onDidDismiss();
            console.log(result);
        });
    }
};
EdituserprofilePage.ctorParameters = () => [
    { type: _service_user_service__WEBPACK_IMPORTED_MODULE_3__.UserService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.ActivatedRoute },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.AlertController }
];
EdituserprofilePage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-edituserprofile',
        template: _edituserprofile_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_edituserprofile_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], EdituserprofilePage);



/***/ }),

/***/ 8297:
/*!**********************************************************************!*\
  !*** ./src/app/edituserprofile/edituserprofile.page.scss?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJlZGl0dXNlcnByb2ZpbGUucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 7657:
/*!**********************************************************************!*\
  !*** ./src/app/edituserprofile/edituserprofile.page.html?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "<ion-content [fullscreen]=\"true\">\n  <ion-header>\n    <ion-toolbar class=\"ios hydrated\" color=\"primary\">\n      <ion-buttons slot=\"start\">\n        <ion-back-button defaultHref=\"home\" style=\"color: black;\"></ion-back-button>\n      </ion-buttons>\n      <ion-title class=\"ios title-ios hydrated\" style=\"color: black;\">Edit UserProfile</ion-title>\n    </ion-toolbar>\n  </ion-header>\n  <ion-grid class=\"main-header\">\n    <div align=\"center\">\n      <ion-avatar>\n        <img src=\"../../assets/userpng.png\" />\n      </ion-avatar>\n    </div>\n  </ion-grid>\n  <form [formGroup]=\"updateUser\" (ngSubmit)=\"updateForm()\">\n  <ion-row class=\"ion-padding-horizontal\">\n    <ion-col size=\"6\">\n      <ion-item lines=\"none\" class=\"ion-text-center\">\n        <!-- <ion-icon name=\"water\" color=\"primary\"></ion-icon> -->\n        <ion-label>\n          <ion-label position=\"floating\">Balance Amount</ion-label>\n          <ion-input formControlName=\"userBalanceAmount\" placeholder=\"BalanceAmount\" type=\"number\" required></ion-input>\n        </ion-label>\n      </ion-item>\n    </ion-col>\n    <ion-col size=\"6\">\n      <ion-item lines=\"none\" class=\"ion-text-center\">\n        <!-- <ion-icon name=\"trophy\" color=\"primary\"></ion-icon> -->\n        <ion-label>\n          <ion-label position=\"floating\">Auto Number</ion-label>\n          <ion-input formControlName=\"autoNumber\" type=\"text\" placeholder=\"autoNumber\" required></ion-input>\n        </ion-label>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n\n  <ion-list lines=\"full\">\n    <ion-item>\n      <ion-label>\n        <ion-label position=\"floating\">Name</ion-label>\n        <ion-input formControlName=\"userName\" type=\"text\" required></ion-input>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-label position=\"floating\">Password</ion-label>\n        <ion-input formControlName=\"userPassword\" type=\"text\" required></ion-input>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-label position=\"floating\">Phone</ion-label>\n        <ion-input formControlName=\"userMobileNumber\" type=\"text\" required></ion-input>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-label position=\"floating\">User TotalAmount</ion-label>\n        <ion-input formControlName=\"userTotalAmount\" type=\"number\" required></ion-input>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-label position=\"floating\">User AcceptedAmount</ion-label>\n        <ion-input formControlName=\"userAcceptedAmount\" type=\"number\" required></ion-input>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-label position=\"floating\">User ProfilePicture</ion-label>\n        <ion-input formControlName=\"userProfilePicture\" type=\"text\" required></ion-input>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-label position=\"floating\">User Status</ion-label>\n        <ion-input formControlName=\"userStatus\" type=\"text\" required></ion-input>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-label position=\"floating\">Role</ion-label>\n        <ion-input formControlName=\"role\" type=\"text\" required></ion-input>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-label position=\"floating\">Family Numbers Name</ion-label>\n        <ion-input formControlName=\"familyNumberNames\" type=\"text\" required></ion-input>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-label position=\"floating\">Id Proof</ion-label>\n        <ion-input formControlName=\"identityProof\" type=\"text\" required></ion-input>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n        <ion-label position=\"floating\">Address</ion-label>\n        <ion-input formControlName=\"userAddress\" type=\"text\" required></ion-input>\n      </ion-label>\n    </ion-item>\n    <br>\n      <ion-col>\n        <ion-button type=\"submit\" color=\"primary\" shape=\"full\" expand=\"block\">Add</ion-button>\n      </ion-col>\n  </ion-list>\n</form>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_edituserprofile_edituserprofile_module_ts.js.map